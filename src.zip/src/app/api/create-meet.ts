import type { NextApiRequest, NextApiResponse } from 'next';
import { getToken } from "next-auth/jwt";
import { google } from "googleapis";
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const token = await getToken({ req });
  if (!token) return res.status(401).json({ error: "Unauthorized" });

  const oauth2Client = new google.auth.OAuth2();
  oauth2Client.setCredentials({ access_token: token.accessToken as string });


  const calendar = google.calendar({ version: "v3", auth: oauth2Client });

  const event = await calendar.events.insert({
    calendarId: "primary",
    conferenceDataVersion: 1,
    requestBody: {
      summary: "Consultation Meeting",
      description: "Consultation via Google Meet",
      start: {
        dateTime: new Date().toISOString(),
        timeZone: "Asia/Manila",
      },
      end: {
        dateTime: new Date(new Date().getTime() + 30 * 60000).toISOString(), // 30 minutes
        timeZone: "Asia/Manila",
      },
      conferenceData: {
        createRequest: {
          requestId: Math.random().toString(36).substring(7),
        },
      },
    },
  });

  const meetLink = event.data.hangoutLink;

  // Save to Supabase
  const { data, error } = await supabase.from('consultations').insert([
    { patient_id: token.sub, meet_link: meetLink },
  ]);

  if (error) {
    console.error(error);
    return res.status(500).json({ error: "Database Error" });
  }

  res.status(200).json({ meetLink });
}
